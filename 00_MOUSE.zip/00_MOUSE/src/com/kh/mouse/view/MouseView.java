package com.kh.mouse.view;

import java.util.Scanner;

import com.kh.mouse.controller.MouseController;

public class MouseView {

	private Scanner sc = new Scanner(System.in);
	
	private MouseController mc = new MouseController();
	
	public void mainMenu() {
		
		while(true) {
			
			System.out.println("\n***** 회원 관리 프로그램 *****");
			
			System.out.println("1. 신상품 조회");
			System.out.println("2. 전체 상품 조회");
			System.out.println("3. 키워드로 검색");
			System.out.println("4. 물품 등록");
			System.out.println("5. 물품 정보 변경");
			System.out.println("6. 물품 삭제");
			System.out.println("7. 프로그램 종료");
			
			System.out.println("--------------------------------");
			
			System.out.print("이용할 메뉴 선택 : ");
			int menu = sc.nextInt();
			sc.nextLine();
			
			switch(menu) {
			case 1:
				selectNewMouse();
				break;
			case 2:
				selectAll();
				break;
			case 3:
				selectByKeyword();
				break;
			case 4:
				insertMouse();
				break;
			case 5:
				updateMouse();
				break;
			case 6:
				deleteMouse();
				break;
			case 7:
				System.out.println("프로그램을 종료합니다.");
				return;
			default:
				System.out.println("번호를 잘못 입력하셨습니다. 다시 입력해 주세요.");
			}
		}
		
	}

}
