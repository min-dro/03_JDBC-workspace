package com.kh.mouse.model.dao;

public class MouseDao {

}
