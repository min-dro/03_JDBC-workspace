package com.kh.mouse.common;

public class JDBCTemplate {

}
