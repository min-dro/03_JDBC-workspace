package com.kh.mouse.service;

public class MouseService {

}
